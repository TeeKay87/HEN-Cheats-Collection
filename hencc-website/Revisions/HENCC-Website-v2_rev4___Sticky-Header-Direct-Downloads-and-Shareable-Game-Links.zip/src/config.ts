export const CHEAT_DOWNLOAD_BASE_URL = 'https://raw.githubusercontent.com/TeeKay87/HEN-Cheats-Collection/master/cheats'
