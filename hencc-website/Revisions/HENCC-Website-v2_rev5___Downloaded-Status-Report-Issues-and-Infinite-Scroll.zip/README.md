# HEN Cheats Collection Website v2

React + TypeScript + Vite frontend for the HEN Cheats Collection website.

## Development

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
```

The site reads its generated catalog data from `public/data/`.

Expected cheat downloads referenced by game metadata live at the public root under their format directory, for example `public/json/`, `public/mc4/` and `public/shn/`. Those physical cheat files were not present in the supplied `data.zip`, so this revision reports a friendly message instead of silently failing if a referenced download is missing.
