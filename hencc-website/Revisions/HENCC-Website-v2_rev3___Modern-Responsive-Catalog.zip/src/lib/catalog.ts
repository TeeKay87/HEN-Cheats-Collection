import type { CatalogEntry, Platform } from '../types/catalog'

export const normalizeSearch = (value: string) =>
  value
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[.,:;'’"#\-_()[\]{}!/\\]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()

export const platformFor = (id: string): Platform => {
  if (id.startsWith('CUSA')) return 'PS4'
  if (id.startsWith('PPSA')) return 'PS5'
  return 'Other'
}

export const catalogSearchText = (entry: CatalogEntry) =>
  normalizeSearch(
    [
      entry.id,
      entry.title,
      ...entry.versions.flatMap((version) => version.creators),
      ...entry.versions.flatMap((version) => version.formats),
    ].join(' '),
  )

const numberChunks = (value: string) => value.split('.').map((part) => Number(part) || 0)

export const compareVersions = (a: string, b: string) => {
  const aa = numberChunks(a)
  const bb = numberChunks(b)
  const length = Math.max(aa.length, bb.length)
  for (let index = 0; index < length; index += 1) {
    const diff = (aa[index] ?? 0) - (bb[index] ?? 0)
    if (diff !== 0) return diff
  }
  return a.localeCompare(b)
}

export const displayDate = (isoDate: string | undefined) => {
  if (!isoDate) return null
  const date = new Date(`${isoDate}T00:00:00Z`)
  if (Number.isNaN(date.getTime())) return isoDate
  return new Intl.DateTimeFormat('en', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    timeZone: 'UTC',
  }).format(date)
}

export const formatLabel = (format: string) => format.toUpperCase()

export const makeHash = (id: string, version?: string) =>
  version ? `#${id}-${version}` : `#${id}`

export const parseHash = (hash: string) => {
  const raw = decodeURIComponent(hash.replace(/^#/, '')).trim()
  if (!raw) return null
  const match = raw.match(/^([A-Za-z0-9]+)(?:-(.+))?$/)
  if (!match) return null
  return { id: match[1].toUpperCase(), version: match[2] }
}
